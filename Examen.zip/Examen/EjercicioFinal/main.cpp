#include <GLFW/glfw3.h>
#include <random>
#include <math.h>

constexpr auto ANCHO = 1280;
constexpr auto ALTO = 720;

typedef struct RGB
{
	double R;
	double G;
	double B;
}
RGB;

typedef struct HSV
{
	double H;
	double S;
	double V;
}
HSV;

RGB hsv_a_rgb (HSV color)
{
	RGB color_rgb;
	float C = color.S * color.V;
	float X = C * (1 - abs(fmod(color.H / 60, 2) - 1));
	float m = color.V - C;

	if (color.H >= 0 && color.H < 60)
		color_rgb = { C, X, 0 };
	else if (color.H >= 60 && color.H < 120)
		color_rgb = { X, C, 0 };
	else if (color.H >= 120 && color.H < 180)
		color_rgb = { 0, C, X };
	else if (color.H >= 180 && color.H < 240)
		color_rgb = { 0, X, C };
	else if (color.H >= 240 && color.H < 300)
		color_rgb = { X, 0, C };
	else
		color_rgb = { C, 0, X };
	
	return color_rgb;
}

void dibuja_linea (int x1, int y1, int x2, int y2)
{
	glVertex2i(x1, y1);
	glVertex2i(x2, y2);
}

void dibuja_triangulo(int x, int y, int h, HSV color)
{
	int x1 = x - h / sqrt(3);
	int y1 = y + h / 3;

	int x2 = x + h / sqrt(3);
	int y2 = y + h / 3;

	int x3 = x;
	int y3 = y - 2 * h / 3;

	RGB color_rgb = hsv_a_rgb(color);
	glColor3f(color_rgb.R, color_rgb.G, color_rgb.B);

	dibuja_linea(x1, y1, x2, y2);
	dibuja_linea(x2, y2, x3, y3);
	dibuja_linea(x3, y3, x1, y1);
}

void dibuja_triangulo_invertido(int x, int y, int h, HSV color)
{
	int x1 = x - h / sqrt(3);
	int y1 = y - h / 3;

	int x2 = x + h / sqrt(3);
	int y2 = y - h / 3;

	int x3 = x;
	int y3 = y + 2 * h / 3;

	RGB color_rgb = hsv_a_rgb(color);
	glColor3f(color_rgb.R, color_rgb.G, color_rgb.B);

	dibuja_linea(x1, y1, x2, y2);
	dibuja_linea(x2, y2, x3, y3);
	dibuja_linea(x3, y3, x1, y1);
}

int dibujar_sierpinski(float x, float y, float h, HSV color)
{
	if (h < 5)
		return 0;

	if (x > 0 && y > 0 && x < 1280 && y < 720)
		dibuja_triangulo_invertido(x, y, h, color);

	color.H += 15;
	dibujar_sierpinski(x, y - 2 * h / 3, h / 2, color);
	color.H += 15;
	dibujar_sierpinski(x - h / sqrt(3), y + h / 3, h / 2, color);
	color.H += 15;
	dibujar_sierpinski(x + h / sqrt(3), y + h / 3, h / 2, color);

	return 0;
}

void sierpinski (void)
{
	glClearColor(0, 0, 0, 0);      // Se establece el color del fondo (Negro)
	glClear(GL_COLOR_BUFFER_BIT);  // Se limpia el fondo con el color establecido

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, ANCHO, ALTO, 0, 0, 1);

	glLineWidth(1);
	glBegin(GL_LINES);

	HSV color = { 200, 1, 1 };

	dibuja_triangulo(ANCHO / 2, 2 * ALTO / 3, ALTO, color);
	dibujar_sierpinski(ANCHO / 2, 2 * ALTO / 3, ALTO / 2, color);

	glEnd();

	glFlush();
}

int main (void)
{
	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(ANCHO, ALTO, "Hello World", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	// Se genera en pantalla el triangulo de Sierpinski
	sierpinski();

	/* Swap front and back buffers */
	glfwSwapBuffers(window);

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		/* Poll for and process events */
		glfwPollEvents();
	}

	glfwTerminate();
	return 0;
}